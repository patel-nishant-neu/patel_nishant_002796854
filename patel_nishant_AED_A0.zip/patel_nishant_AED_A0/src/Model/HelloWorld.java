/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author nishn
 */
public class HelloWorld {
    
    public static void main(String[] args) {
        
        
        String name = "Nishant Patel";
        int nuid = 2796854;
        double amountdue = 451835.67;
        float money = 224.55f;
        boolean active = true;
        char initial = 'N';

        System.out.println("The name of student is " + name + " and initial for him is '" + initial + "' and his NEUID is " + nuid + " his college fee due is " + amountdue
        + " and paid fee is " + money + " having current status is " + active);
    }    
    
    
    
}
